const express = require('express');
const Product = require('../models/product');
const router = express.Router();

// Add product to wishlist
router.post('/add', async (req, res) => {
  try {
    const product = new Product(req.body);
    await product.save();
    res.json({ message: 'Product added to wishlist!' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to add product to wishlist' });
  }
});

// Get all wishlist items
router.get('/', async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch wishlist' });
  }
});

// Delete product from wishlist
router.delete('/delete/:id', async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: 'Product removed from wishlist!' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to remove product from wishlist' });
  }
});

module.exports = router;
