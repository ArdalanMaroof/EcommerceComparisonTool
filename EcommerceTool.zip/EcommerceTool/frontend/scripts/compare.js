async function searchProducts() {
    const apiSelect = document.getElementById('api-select').value;
    const searchInput = document.getElementById('search-input').value;

    let apiUrl = '';
    if (apiSelect === 'ASOS') {
        apiUrl = `http://localhost:3000/api/asos?id=${searchInput}`;
    } else {
        apiUrl = `http://localhost:3000/api/rtp?query=${searchInput}`;
    }

    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        displayProducts(data);
    } catch (err) {
        console.error('Error fetching data:', err);
    }
}

function displayProducts(data) {
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';

    if (data && data.products) {
        data.products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.classList.add('product-item');
            productDiv.innerHTML = `
                <img src="${product.imageUrl}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>Price: $${product.price}</p>
                <button onclick="addToWishlist('${product.id}')">Add to Wishlist</button>
            `;
            productList.appendChild(productDiv);
        });
    }
}

async function addToWishlist(productId) {
    const productData = {
        productId: productId,
        name: 'Sample Product',
        price: 100,
        imageUrl: 'sample.jpg',
        reviews: ['Excellent product', 'Worth the price'],
    };

    try {
        await fetch('http://localhost:3000/wishlist/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(productData),
        });
        alert('Product added to wishlist');
    } catch (err) {
        console.error('Error adding product to wishlist:', err);
    }
}
