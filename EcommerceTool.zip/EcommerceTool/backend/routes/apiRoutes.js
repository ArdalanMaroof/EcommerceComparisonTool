const express = require('express');
const axios = require('axios');
const router = express.Router();

// ASOS API
const ASOS_API = 'https://asos2.p.rapidapi.com/products/detail';
const ASOS_HEADERS = {
  'x-rapidapi-host': 'asos2.p.rapidapi.com',
  'x-rapidapi-key': '5e72041517msh4cc1112fbcd76bbp182699jsnbb347e9a6f6d',
};

// Real-Time Product Search API
const RTP_API = 'https://real-time-product-search.p.rapidapi.com/search-v2';
const RTP_HEADERS = {
  'x-rapidapi-host': 'real-time-product-search.p.rapidapi.com',
  'x-rapidapi-key': '5e72041517msh4cc1112fbcd76bbp182699jsnbb347e9a6f6d',
};

// Fetch products from APIs
router.get('/asos', async (req, res) => {
  try {
    const { id } = req.query;
    const response = await axios.get(`${ASOS_API}?lang=en-US&store=US&currency=USD&sizeSchema=US&id=${id}`, { headers: ASOS_HEADERS });
    res.json(response.data);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch data from ASOS API' });
  }
});

router.get('/rtp', async (req, res) => {
  try {
    const { query } = req.query;
    const response = await axios.get(`${RTP_API}?q=${query}&country=us&language=en&page=1&limit=10&sort_by=BEST_MATCH`, { headers: RTP_HEADERS });
    res.json(response.data);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch data from Real-Time Product Search API' });
  }
});

module.exports = router;
