async function fetchWishlist() {
    try {
        const response = await fetch('http://localhost:3000/wishlist');
        const wishlistItems = await response.json();
        displayWishlistItems(wishlistItems);
    } catch (err) {
        console.error('Error fetching wishlist:', err);
    }
}

function displayWishlistItems(items) {
    const wishlistItemsDiv = document.getElementById('wishlist-items');
    wishlistItemsDiv.innerHTML = '';

    items.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('wishlist-item');
        itemDiv.innerHTML = `
            <img src="${item.imageUrl}" alt="${item.name}">
            <h3>${item.name}</h3>
            <p>Price: $${item.price}</p>
            <button onclick="deleteFromWishlist('${item._id}')">Delete</button>
        `;
        wishlistItemsDiv.appendChild(itemDiv);
    });
}

async function deleteFromWishlist(itemId) {
    try {
        await fetch(`http://localhost:3000/wishlist/delete/${itemId}`, { method: 'DELETE' });
        alert('Product removed from wishlist');
        fetchWishlist(); // Refresh the wishlist
    } catch (err) {
        console.error('Error removing item from wishlist:', err);
    }
}

fetchWishlist();
