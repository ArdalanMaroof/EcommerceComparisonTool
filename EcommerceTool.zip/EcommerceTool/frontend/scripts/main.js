// This file will handle general tasks across multiple pages

// This function will initialize the page, setting up any necessary data or actions for the home page
function initHomePage() {
    console.log("Home Page Loaded");
    // You can add any specific logic or functionality for the homepage here
}

// This function will be used to initialize the Compare Page
function initComparePage() {
    console.log("Compare Page Loaded");
    // You can add logic specific to the compare page here
    // For example, pre-fill the search bar, load initial products, etc.
}

// This function will initialize the Wishlist Page
function initWishlistPage() {
    console.log("Wishlist Page Loaded");
    // Any logic related to displaying the wishlist can be added here
}

// Page-specific initializations
document.addEventListener("DOMContentLoaded", function () {
    const pageTitle = document.title.toLowerCase();
    
    if (pageTitle.includes('home')) {
        initHomePage();
    } else if (pageTitle.includes('compare')) {
        initComparePage();
    } else if (pageTitle.includes('wishlist')) {
        initWishlistPage();
    }
});
