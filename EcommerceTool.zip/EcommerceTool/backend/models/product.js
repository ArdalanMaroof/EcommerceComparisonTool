const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
  apiName: String,
  productId: String,
  name: String,
  price: Number,
  imageUrl: String,
  reviews: [String],
});

module.exports = mongoose.model('Product', ProductSchema);
